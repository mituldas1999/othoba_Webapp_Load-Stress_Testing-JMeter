/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.91156462585035, "KoPercent": 1.08843537414966};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5603333333333333, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.5166666666666667, 500, 1500, "https://www.othoba.com/-43"], "isController": false}, {"data": [0.8666666666666667, 500, 1500, "https://www.othoba.com/-42"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "https://www.othoba.com/Country/GetDivisionsByCountryId?countryId=237"], "isController": false}, {"data": [0.06666666666666667, 500, 1500, "https://www.othoba.com/-41"], "isController": false}, {"data": [0.5666666666666667, 500, 1500, "https://www.othoba.com/-40"], "isController": false}, {"data": [0.7, 500, 1500, "https://www.othoba.com/-38"], "isController": false}, {"data": [0.6, 500, 1500, "https://www.othoba.com/-37"], "isController": false}, {"data": [0.7, 500, 1500, "https://www.othoba.com/-36"], "isController": false}, {"data": [0.6, 500, 1500, "https://www.othoba.com/-35"], "isController": false}, {"data": [0.75, 500, 1500, "https://www.othoba.com/-34"], "isController": false}, {"data": [0.7666666666666667, 500, 1500, "https://www.othoba.com/-33"], "isController": false}, {"data": [0.7166666666666667, 500, 1500, "https://www.othoba.com/-32"], "isController": false}, {"data": [0.65, 500, 1500, "https://www.othoba.com/-31"], "isController": false}, {"data": [0.7, 500, 1500, "https://www.othoba.com/-39"], "isController": false}, {"data": [0.1, 500, 1500, "https://www.othoba.com/-0"], "isController": false}, {"data": [0.016666666666666666, 500, 1500, "https://www.othoba.com/-1"], "isController": false}, {"data": [0.5666666666666667, 500, 1500, "https://www.othoba.com/HomeComponent/OnLoadProduct?_=1662816362148"], "isController": false}, {"data": [0.6, 500, 1500, "https://www.othoba.com/-30"], "isController": false}, {"data": [0.55, 500, 1500, "https://www.othoba.com/-27"], "isController": false}, {"data": [0.5, 500, 1500, "https://www.othoba.com/-26"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://www.othoba.com/-25"], "isController": false}, {"data": [0.43333333333333335, 500, 1500, "https://www.othoba.com/-24"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://www.othoba.com/-23"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://www.othoba.com/-22"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://www.othoba.com/-21"], "isController": false}, {"data": [0.4, 500, 1500, "https://www.othoba.com/-20"], "isController": false}, {"data": [0.7666666666666667, 500, 1500, "https://www.othoba.com/-8"], "isController": false}, {"data": [0.8166666666666667, 500, 1500, "https://www.othoba.com/-9"], "isController": false}, {"data": [0.7, 500, 1500, "https://www.othoba.com/-6"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.othoba.com/ProductDeal/GetDealsCount"], "isController": false}, {"data": [0.6666666666666666, 500, 1500, "https://www.othoba.com/-7"], "isController": false}, {"data": [0.31666666666666665, 500, 1500, "https://www.othoba.com/-4"], "isController": false}, {"data": [0.7166666666666667, 500, 1500, "https://www.othoba.com/-5"], "isController": false}, {"data": [0.08333333333333333, 500, 1500, "https://www.othoba.com/-2"], "isController": false}, {"data": [0.43333333333333335, 500, 1500, "https://www.othoba.com/-29"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://www.othoba.com/-3"], "isController": false}, {"data": [0.45, 500, 1500, "https://www.othoba.com/-28"], "isController": false}, {"data": [0.7666666666666667, 500, 1500, "https://www.othoba.com/-16"], "isController": false}, {"data": [0.9666666666666667, 500, 1500, "https://www.othoba.com/-15"], "isController": false}, {"data": [0.9333333333333333, 500, 1500, "https://www.othoba.com/-14"], "isController": false}, {"data": [0.95, 500, 1500, "https://www.othoba.com/-13"], "isController": false}, {"data": [0.95, 500, 1500, "https://www.othoba.com/-12"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "https://www.othoba.com/-11"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "https://www.othoba.com/-10"], "isController": false}, {"data": [0.43333333333333335, 500, 1500, "https://www.othoba.com/HomeComponent/GetSpecialBlock"], "isController": false}, {"data": [0.13333333333333333, 500, 1500, "https://www.othoba.com/-19"], "isController": false}, {"data": [0.0, 500, 1500, "https://www.othoba.com/"], "isController": false}, {"data": [0.43333333333333335, 500, 1500, "https://www.othoba.com/-18"], "isController": false}, {"data": [0.05, 500, 1500, "https://www.othoba.com/-17"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1470, 16, 1.08843537414966, 3715.9612244897926, 0, 77942, 683.0, 7571.800000000002, 25516.70000000004, 52297.15999999999, 17.460505998337094, 1751.0441064296533, 18.710492078928613], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Test", 30, 6, 20.0, 52333.46666666667, 33428, 82916, 51138.0, 64742.8, 81576.2, 82916.0, 0.3561253561253561, 898.9342786421238, 9.912051411888653], "isController": true}, {"data": ["https://www.othoba.com/-43", 30, 0, 0.0, 2669.2666666666664, 55, 37879, 917.5, 6523.900000000009, 22757.29999999998, 37879.0, 0.49411183397842373, 6.0456319999176475, 0.41787192209503415], "isController": false}, {"data": ["https://www.othoba.com/-42", 30, 0, 0.0, 406.06666666666666, 55, 3485, 88.0, 1183.5000000000005, 2801.899999999999, 3485.0, 0.4950576742190465, 0.5284160526576347, 0.4336589197016453], "isController": false}, {"data": ["https://www.othoba.com/Country/GetDivisionsByCountryId?countryId=237", 30, 0, 0.0, 610.7333333333333, 55, 7766, 61.0, 990.1000000000022, 7736.85, 7766.0, 0.5929322476085066, 0.559348194521306, 0.46149121224998024], "isController": false}, {"data": ["https://www.othoba.com/-41", 30, 4, 13.333333333333334, 15730.133333333333, 313, 51336, 13156.5, 37483.80000000001, 45425.149999999994, 51336.0, 0.4726791453961051, 108.49405039744437, 0.359648513817987], "isController": false}, {"data": ["https://www.othoba.com/-40", 30, 0, 0.0, 1538.9666666666667, 107, 10369, 977.0, 3576.5000000000005, 7277.449999999996, 10369.0, 0.4943805411818991, 6.849391345456643, 0.4345141475231535], "isController": false}, {"data": ["https://www.othoba.com/-38", 30, 0, 0.0, 1153.2666666666667, 164, 11790, 450.0, 2860.9000000000024, 7617.699999999995, 11790.0, 0.4939491232403062, 0.4411776055816251, 0.1818543158804643], "isController": false}, {"data": ["https://www.othoba.com/-37", 30, 0, 0.0, 2187.133333333333, 55, 38685, 547.0, 3163.300000000001, 19366.249999999975, 38685.0, 0.4946087644673064, 2.968135603175388, 0.42408837422099116], "isController": false}, {"data": ["https://www.othoba.com/-36", 30, 1, 3.3333333333333335, 824.6333333333332, 57, 3497, 433.5, 2945.7000000000003, 3367.75, 3497.0, 0.4932101404004866, 3.0333868586213133, 0.40925845341630224], "isController": false}, {"data": ["https://www.othoba.com/-35", 30, 0, 0.0, 964.0666666666666, 54, 4986, 580.5, 2447.2000000000007, 3790.8499999999985, 4986.0, 0.49467400982752363, 2.4835147309797843, 0.42994127807275007], "isController": false}, {"data": ["https://www.othoba.com/-34", 30, 0, 0.0, 828.7333333333333, 57, 10732, 201.0, 1707.5000000000002, 6275.899999999994, 10732.0, 0.49464954080034296, 2.0607177158733037, 0.42943695485498523], "isController": false}, {"data": ["https://www.othoba.com/-33", 30, 0, 0.0, 602.5666666666665, 62, 3579, 376.5, 1730.4000000000008, 2817.7999999999993, 3579.0, 0.49474743143625177, 1.7678523941652786, 0.42662302925606477], "isController": false}, {"data": ["https://www.othoba.com/-32", 30, 0, 0.0, 1062.5666666666666, 56, 9583, 264.5, 2008.5000000000002, 7205.899999999997, 9583.0, 0.4946087644673064, 1.8489866702937976, 0.4269864724502918], "isController": false}, {"data": ["https://www.othoba.com/-31", 30, 0, 0.0, 1373.4333333333334, 55, 9443, 532.0, 6426.800000000005, 8415.05, 9443.0, 0.4947555907381753, 1.6611032431228971, 0.4285627040866812], "isController": false}, {"data": ["https://www.othoba.com/-39", 30, 0, 0.0, 1343.7333333333331, 56, 21576, 526.0, 2370.7000000000025, 11129.849999999986, 21576.0, 0.4948371985616732, 2.687777830468776, 0.4281501542242602], "isController": false}, {"data": ["https://www.othoba.com/-0", 30, 0, 0.0, 15769.866666666669, 415, 60610, 10212.5, 44525.00000000001, 54590.24999999999, 60610.0, 0.4822065772977143, 70.97532998501141, 0.15869493803645482], "isController": false}, {"data": ["https://www.othoba.com/-1", 30, 0, 0.0, 25501.33333333333, 1198, 73728, 26778.0, 47758.100000000006, 62241.249999999985, 73728.0, 0.3822483850005734, 139.60241091223577, 0.3359604946294102], "isController": false}, {"data": ["https://www.othoba.com/HomeComponent/OnLoadProduct?_=1662816362148", 30, 0, 0.0, 974.5666666666667, 170, 3562, 739.0, 1813.9000000000003, 2868.999999999999, 3562.0, 0.5545901578733315, 35.61855288941472, 0.43056560108329944], "isController": false}, {"data": ["https://www.othoba.com/-30", 30, 0, 0.0, 1028.6666666666665, 121, 9799, 678.0, 1370.5000000000002, 5570.049999999995, 9799.0, 0.49398979087765515, 34.50039493454636, 0.17656275728634943], "isController": false}, {"data": ["https://www.othoba.com/-27", 30, 0, 0.0, 957.1333333333336, 323, 3997, 717.0, 2383.200000000002, 3656.5499999999997, 3997.0, 0.49251379038613075, 35.090934206314024, 0.17603520242316786], "isController": false}, {"data": ["https://www.othoba.com/-26", 30, 0, 0.0, 995.8666666666669, 266, 3099, 772.0, 1919.5, 2809.1499999999996, 3099.0, 0.4902441415825081, 45.32121970699742, 0.1752239802921855], "isController": false}, {"data": ["https://www.othoba.com/-25", 30, 0, 0.0, 1210.0666666666666, 334, 5972, 814.0, 2096.6000000000004, 4437.499999999998, 5972.0, 0.4914004914004914, 51.937624769656026, 0.175637285012285], "isController": false}, {"data": ["https://www.othoba.com/-24", 30, 0, 0.0, 1770.2666666666664, 290, 19861, 1064.0, 2988.2000000000025, 10778.299999999988, 19861.0, 0.48760666395774077, 61.78211347013409, 0.17428128809427063], "isController": false}, {"data": ["https://www.othoba.com/-23", 30, 0, 0.0, 1201.3666666666663, 76, 3481, 995.5, 2625.2000000000016, 3187.8499999999995, 3481.0, 0.4879715024642561, 50.97205448201825, 0.17441168935734153], "isController": false}, {"data": ["https://www.othoba.com/-22", 30, 0, 0.0, 1184.8, 81, 5686, 1036.5, 1922.0000000000007, 4148.199999999998, 5686.0, 0.48813824074978035, 50.83235197207849, 0.17447128526798789], "isController": false}, {"data": ["https://www.othoba.com/-21", 30, 0, 0.0, 1355.6333333333332, 76, 6012, 1071.5, 3025.2000000000003, 4519.8499999999985, 6012.0, 0.4880111917233302, 36.70352506750822, 0.17442587516673716], "isController": false}, {"data": ["https://www.othoba.com/-20", 30, 1, 3.3333333333333335, 2288.7666666666664, 0, 21704, 1349.0, 5975.900000000001, 13352.249999999989, 21704.0, 0.4884004884004884, 1.0183436355311355, 0.40987802706552706], "isController": false}, {"data": ["https://www.othoba.com/-8", 30, 1, 3.3333333333333335, 761.6, 4, 6608, 274.0, 2446.9000000000024, 4445.399999999997, 6608.0, 0.4867838193058463, 0.5881337316847588, 0.16910667056093723], "isController": false}, {"data": ["https://www.othoba.com/-9", 30, 0, 0.0, 523.4333333333333, 73, 2291, 181.0, 1866.3000000000004, 2275.6, 2291.0, 0.48706833568749697, 0.646649806999172, 0.1750401831376942], "isController": false}, {"data": ["https://www.othoba.com/-6", 30, 0, 0.0, 698.6999999999999, 161, 2607, 477.0, 1569.1000000000008, 2279.2, 2607.0, 0.4863418983545433, 0.6022913795898517, 0.17477911972116397], "isController": false}, {"data": ["https://www.othoba.com/ProductDeal/GetDealsCount", 30, 0, 0.0, 97.13333333333333, 57, 494, 60.0, 278.3000000000004, 436.24999999999994, 494.0, 0.5933309600094934, 0.34939313367746533, 0.49888472321110716], "isController": false}, {"data": ["https://www.othoba.com/-7", 30, 0, 0.0, 1012.2000000000002, 170, 6416, 459.5, 2313.6, 4881.499999999998, 6416.0, 0.4854840275754928, 0.6025880850082532, 0.17447082240994272], "isController": false}, {"data": ["https://www.othoba.com/-4", 30, 0, 0.0, 2793.3999999999996, 69, 9713, 2105.5, 7077.700000000001, 9216.349999999999, 9713.0, 0.4861921431349669, 4.191508046479969, 0.4216197491248541], "isController": false}, {"data": ["https://www.othoba.com/-5", 30, 0, 0.0, 1026.8, 170, 11872, 328.0, 2240.1000000000013, 6695.949999999993, 11872.0, 0.4864128672417148, 0.6397469234386147, 0.17480462416499123], "isController": false}, {"data": ["https://www.othoba.com/-2", 30, 0, 0.0, 16280.7, 582, 70941, 12639.5, 42372.700000000026, 58214.54999999998, 70941.0, 0.3941818755173637, 42.59319937719264, 0.34606397079112305], "isController": false}, {"data": ["https://www.othoba.com/-29", 30, 0, 0.0, 1225.0333333333338, 266, 2958, 1108.5, 2324.1000000000004, 2955.8, 2958.0, 0.4937458854509546, 60.03458149893022, 0.1764755801514154], "isController": false}, {"data": ["https://www.othoba.com/-3", 30, 0, 0.0, 1430.9999999999995, 55, 7121, 818.5, 3681.600000000001, 6612.249999999999, 7121.0, 0.48621578256430203, 1.3741293698643458, 0.40454672533670444], "isController": false}, {"data": ["https://www.othoba.com/-28", 30, 0, 0.0, 1061.8, 293, 2373, 896.0, 1756.4, 2099.6499999999996, 2373.0, 0.4899318994659742, 63.070885490666804, 0.17511237812944003], "isController": false}, {"data": ["https://www.othoba.com/-16", 30, 0, 0.0, 551.0333333333333, 171, 2339, 306.0, 1306.7000000000003, 1834.0999999999995, 2339.0, 0.48672853527159454, 2.1875215478778633, 0.17349210485755076], "isController": false}, {"data": ["https://www.othoba.com/-15", 30, 0, 0.0, 203.39999999999998, 69, 670, 111.0, 464.0, 588.05, 670.0, 0.4882494629255908, 0.5518553988184363, 0.17546465073888418], "isController": false}, {"data": ["https://www.othoba.com/-14", 30, 0, 0.0, 248.06666666666672, 71, 1447, 109.5, 594.5000000000001, 1162.0999999999997, 1447.0, 0.4881779571379754, 0.6597712377752103, 0.1754389533464599], "isController": false}, {"data": ["https://www.othoba.com/-13", 30, 0, 0.0, 239.96666666666667, 76, 1299, 107.5, 645.7000000000005, 1261.6, 1299.0, 0.48763044114300574, 0.6105698215678944, 0.1752421897857677], "isController": false}, {"data": ["https://www.othoba.com/-12", 30, 0, 0.0, 210.60000000000002, 63, 1384, 103.5, 496.80000000000007, 925.2999999999994, 1384.0, 0.48725819811918336, 0.6335784089801686, 0.1751084149490815], "isController": false}, {"data": ["https://www.othoba.com/-11", 30, 0, 0.0, 294.8333333333334, 68, 1498, 121.0, 992.5000000000008, 1386.8999999999999, 1498.0, 0.4867996170509679, 0.5830502965421, 0.1749436123776916], "isController": false}, {"data": ["https://www.othoba.com/-10", 30, 0, 0.0, 455.3666666666668, 61, 5429, 149.0, 1242.3000000000015, 3268.0499999999975, 5429.0, 0.4864759680871765, 0.5800972546539535, 0.17482730103132904], "isController": false}, {"data": ["https://www.othoba.com/HomeComponent/GetSpecialBlock", 30, 0, 0.0, 1759.0666666666666, 218, 9698, 1152.0, 3865.6000000000017, 8683.249999999998, 9698.0, 0.48304511641387304, 33.15826407170805, 0.36841624601487777], "isController": false}, {"data": ["https://www.othoba.com/-19", 30, 1, 3.3333333333333335, 3204.8666666666663, 121, 10263, 2853.5, 7069.9000000000015, 8553.049999999997, 10263.0, 0.4875670404680643, 173.99653560763042, 0.1790443939947993], "isController": false}, {"data": ["https://www.othoba.com/", 30, 6, 20.0, 48891.96666666667, 19988, 77942, 46348.0, 63826.9, 75354.25, 77942.0, 0.3787161522438932, 905.0581289844094, 9.344759416619327], "isController": false}, {"data": ["https://www.othoba.com/-18", 30, 0, 0.0, 1916.333333333333, 159, 13007, 1136.0, 5340.400000000005, 9359.949999999995, 13007.0, 0.4887585532746823, 5.979878166748126, 0.1861482771260997], "isController": false}, {"data": ["https://www.othoba.com/-17", 30, 2, 6.666666666666667, 11661.166666666668, 145, 39506, 6959.5, 36370.40000000002, 39448.8, 39506.0, 0.48063058733057773, 35.27199560823801, 0.39382920391553716], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, 6.25, 0.06802721088435375], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 9, 56.25, 0.6122448979591837], "isController": false}, {"data": ["Assertion failed", 6, 37.5, 0.40816326530612246], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1470, 16, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 9, "Assertion failed", 6, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.othoba.com/-41", 30, 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.othoba.com/-36", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.othoba.com/-20", 30, 1, "Non HTTP response code: java.lang.IllegalStateException/Non HTTP response message: Connection pool shut down", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://www.othoba.com/-8", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.othoba.com/-19", 30, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["https://www.othoba.com/", 30, 6, "Assertion failed", 6, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.othoba.com/-17", 30, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
